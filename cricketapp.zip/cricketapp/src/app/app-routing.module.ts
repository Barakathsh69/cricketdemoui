import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AddPlayerComponent } from './add-player/add-player.component';
import { DeletePlayerComponent } from './delete-player/delete-player.component';
import { ViewPlayersComponent } from './view-players/view-players.component';
import { UpdatePlayerComponent } from './update-player/update-player.component';
import { ViewSelectedPlayerComponent } from './view-selected-player/view-selected-player.component';
import { EditPlayerComponent } from './edit-player/edit-player.component';

const routes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'add', component: AddPlayerComponent },
  { path: 'delete', component: DeletePlayerComponent },
  { path: 'update', component: UpdatePlayerComponent },
  { path: 'view', component: ViewPlayersComponent },
  { path: 'edit/:id', component: EditPlayerComponent },
  { path: 'viewselectedplayer/:id', component: ViewSelectedPlayerComponent}
];
@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}