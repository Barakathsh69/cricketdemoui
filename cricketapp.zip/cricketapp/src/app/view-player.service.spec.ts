import { TestBed } from '@angular/core/testing';

import { ViewPlayerService } from './view-player.service';

describe('ViewPlayerService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ViewPlayerService = TestBed.get(ViewPlayerService);
    expect(service).toBeTruthy();
  });
});
