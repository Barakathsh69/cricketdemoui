
export class Players
{
    id: number;
    name: string;
    image: string;
    country: string;
    category: string
}