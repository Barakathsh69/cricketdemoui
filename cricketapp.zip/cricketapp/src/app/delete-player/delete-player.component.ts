import { Component, OnInit } from '@angular/core';
import { CricketappService } from '../cricketapp.service';
import { Router } from '@angular/router';
import { Players } from '../players';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ViewPlayerService } from '../view-player.service';

@Component({
  selector: 'app-delete-player',
  templateUrl: './delete-player.component.html',
  styleUrls: ['./delete-player.component.scss']
})
export class DeletePlayerComponent implements OnInit {

  players: Players[];
  constructor(private router: Router, 
    private cricketService: CricketappService, 
    private viewPlayersService: ViewPlayerService, 
    private modalService: NgbModal) { }
  ngOnInit() {
    this.getAllPlayers();
  }

  getAllPlayers() {
    this.viewPlayersService.getAllPlayers().subscribe(
      (data: any) => {
        this.players = data;
      },
      err => {
        console.log(err);
      }
    );
  }

  // open(content) {
  //     this.modalService.open(content);
  // }

  open(content, player) {
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
      this.onConfirm(player);
    }, (reason) => {
      console.log(reason)
    });
  }

  onConfirm(player) {
   let check=confirm("do you want to delete ?");
   if(check){
    this.cricketService.deletePlayer(player).subscribe(
      (data: any) => {
        this.players = data;
      },
      err => {
        console.log(err);
      }
    );
   }
  }

}
