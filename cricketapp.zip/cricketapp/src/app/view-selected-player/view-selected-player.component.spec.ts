import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewSelectedPlayerComponent } from './view-selected-player.component';

describe('ViewSelectedPlayerComponent', () => {
  let component: ViewSelectedPlayerComponent;
  let fixture: ComponentFixture<ViewSelectedPlayerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewSelectedPlayerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewSelectedPlayerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
