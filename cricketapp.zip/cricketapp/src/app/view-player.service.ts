import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ViewPlayerService {

  private baseURL = "http://localhost:8090/cricketapp/";
  constructor(private http: HttpClient) { }
  // retrive the all the player info from the db
  getAllPlayers() {
    return this.http.get(this.baseURL + 'viewplayers');
  }
}
