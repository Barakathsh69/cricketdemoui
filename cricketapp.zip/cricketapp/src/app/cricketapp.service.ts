import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import {Players} from './players'

@Injectable({
  providedIn: 'root'
})
export class CricketappService {
  
  private baseURL = "http://localhost:8090/cricketapp/";
  constructor(private http: HttpClient) { }

  getSelectedPlayer(id: number) {
    return this.http.get(this.baseURL+'selectedplayer'+"/"+id);
  }

  updatePlayer(player: Players)
  {    
    return this.http.put(this.baseURL+'updateplayer', player);
  }

  deletePlayer(player: Players)
  {
    return this.http.get(this.baseURL+'deleteplayer'+"/"+player.id);
  }
}



