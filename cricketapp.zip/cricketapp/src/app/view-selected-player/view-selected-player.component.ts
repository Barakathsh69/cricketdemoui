import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Players } from '../players';
import { CricketappService } from '../cricketapp.service';

@Component({
  selector: 'app-view-selected-player',
  templateUrl: './view-selected-player.component.html',
  styleUrls: ['./view-selected-player.component.scss']
})
export class ViewSelectedPlayerComponent implements OnInit {

  public player: Players = new Players(); 
  constructor(private http: HttpClient, private router: Router, private crickService: CricketappService, private route: ActivatedRoute, ) { }

  ngOnInit() {

    let id = this.route.snapshot.paramMap.get('id');   
    this.getSelectedPlayer(id);
  }

  getSelectedPlayer(id) {
    return this.crickService.getSelectedPlayer(id).subscribe((data: Players) => {
      this.player = data;
    }, error => { console.log("selcted Player error"); }

    );
  }

}
