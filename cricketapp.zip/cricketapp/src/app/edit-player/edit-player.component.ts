import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Players } from '../players'
import { Router } from '@angular/router';
import { CricketappService } from '../cricketapp.service';
@Component({
  selector: 'app-edit-player',
  templateUrl: './edit-player.component.html',
  styleUrls: ['./edit-player.component.scss']
})
export class EditPlayerComponent implements OnInit {

  public player: Players = new Players();
  // categories = ['batting', 'bowling', 'Wicket Keeper','Left-hand batsman', 'Right-hand batsman', 'All Rounder']; 
  public categories = ['batting', 'wicketKeeper','bowling', 'Left-hand batsman', 'Right-hand batsman', 'All Rounder']; 
  public countries = ['India', 'Australia','England', 'Sri Lanka', 'South Africa', 'Pakistan']; 
  constructor(private http: HttpClient, private router: Router, private crickService: CricketappService, 
    private route: ActivatedRoute, ) { }

  ngOnInit() {

    let id = this.route.snapshot.paramMap.get('id');   
    this.getSelectedPlayer(id);
  }

  getSelectedPlayer(id) {
    return this.crickService.getSelectedPlayer(id).subscribe((data: Players) => {
      this.player = data;
    }, error => { console.log("selcted Player error"); }

    );
  }

  onUpdate()
  {
    
    this.crickService.updatePlayer(this.player).subscribe(
      (player: any) => {
        this.router.navigate(['/update']);
      },
      err => {
        console.log(err);
      }
    );
  }
}


