import { TestBed } from '@angular/core/testing';

import { CricketappService } from './cricketapp.service';

describe('CricketappService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CricketappService = TestBed.get(CricketappService);
    expect(service).toBeTruthy();
  });
});
