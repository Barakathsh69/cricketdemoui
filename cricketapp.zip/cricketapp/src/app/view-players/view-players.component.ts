import { Component, OnInit } from '@angular/core';
import { Players } from '../players';
import { Router } from '@angular/router';
import { ViewPlayerService } from '../view-player.service';

@Component({
  selector: 'app-view-players',
  templateUrl: './view-players.component.html',
  styleUrls: ['./view-players.component.scss']
})
export class ViewPlayersComponent implements OnInit {

  players: Players[];

  constructor(private router: Router, private viewPlayersService: ViewPlayerService) { }
  ngOnInit() {
    this.getAllPlayers();
  }

  getAllPlayers() {
    this.viewPlayersService.getAllPlayers().subscribe(
      (data: any) => {
        this.players = data;
      },
      err => {
        console.log(err);
      }
    );
  }
}
