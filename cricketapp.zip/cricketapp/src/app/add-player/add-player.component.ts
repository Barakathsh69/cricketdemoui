import { Component, OnInit } from '@angular/core';
import { Players } from '../players';
import { Router } from '@angular/router';
import { AddPlayerService } from '../add-player.service';

@Component({
  selector: 'app-add-player',
  templateUrl: './add-player.component.html',
  styleUrls: ['./add-player.component.scss']
})
export class AddPlayerComponent implements OnInit {

  player: Players = new Players();
  public categories = ['batting', 'wicketKeeper','bowling', 'Left-hand batsman', 'Right-hand batsman', 'All Rounder']; 
  public countries = ['India', 'Australia','England', 'Sri Lanka', 'South Africa', 'Pakistan']; 
  constructor(private router: Router, private addPlayersService: AddPlayerService) { }

  ngOnInit() {
  }
  onSubmit() {
      this.addPlayersService.savePlayer(this.player).subscribe(
        (player: any) => {
          this.router.navigate(['/view']);
        },
        err => {
          console.log(err);
        }
      );
    }

}
