import { Injectable } from '@angular/core';
import { Players } from './players';
import { HttpClientModule, HttpClient } from '@angular/common/http';



@Injectable({
  providedIn: 'root'
})
export class AddPlayerService {

  //  constructor() { }
  private baseURL = "http://localhost:8090/cricketapp/";
  constructor(private http: HttpClient) { }

  savePlayer(player: Players) {
    return this.http.post(this.baseURL + 'addplayer', player);
  }
}
