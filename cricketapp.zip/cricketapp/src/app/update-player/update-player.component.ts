import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ViewPlayerService } from '../view-player.service';
import { Players } from '../players';

@Component({
  selector: 'app-update-player',
  templateUrl: './update-player.component.html',
  styleUrls: ['./update-player.component.scss']
})
export class UpdatePlayerComponent implements OnInit {

  players: Players[];
  selectedPlayerId: number;

  constructor(private router: Router, private viewPlayersService: ViewPlayerService) { }
  
  ngOnInit() {
    this.getAllPlayers();
  }

  getAllPlayers() {
    this.viewPlayersService.getAllPlayers().subscribe(
      (data: any) => {
        this.players = data;
      },
      err => {
        console.log(err);
      }
    );
  }


  
  getPlayerDetails(event: any)
  {    
    this.selectedPlayerId = event.target.value;
  }

}
